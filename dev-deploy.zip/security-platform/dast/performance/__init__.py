"""AGT DAST - performance."""

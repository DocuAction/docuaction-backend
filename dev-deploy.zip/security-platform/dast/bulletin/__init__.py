"""AGT DAST - bulletin."""
